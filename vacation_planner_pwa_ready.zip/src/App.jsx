import React, { useMemo, useState, useEffect, createContext, useContext } from 'react'
import { BrowserRouter, Routes, Route, Link, NavLink, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'

const ThemeContext = createContext(null);
const useTheme = () => useContext(ThemeContext);
const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(() => localStorage.getItem('vp_theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  useEffect(() => {
    localStorage.setItem('vp_theme', theme);
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);
  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>
}

const Shell = ({ children }) => {
  const { theme, setTheme } = useTheme();
  return (
    <div className="min-h-screen theme-transition bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 dark:bg-slate-900/70 border-b border-slate-200/60 dark:border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-4">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-2xl animated-banner shadow" />
            <span className="font-bold text-xl">VacayPlan</span>
          </Link>
          <nav className="ml-auto hidden md:flex items-center gap-2">
            <TopNavLink to="/hotels">Hotels</TopNavLink>
            <TopNavLink to="/transport">Transport</TopNavLink>
            <TopNavLink to="/rentals">Rentals</TopNavLink>
            <TopNavLink to="/food">Food</TopNavLink>
            <TopNavLink to="/calculator">Cost</TopNavLink>
            <TopNavLink to="/bookings">My Bookings</TopNavLink>
          </nav>
          <ThemeToggle theme={theme} setTheme={setTheme} />
          <AuthButtons />
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">{children}</main>
      <BottomNav />
      <footer className="mt-16 border-t border-slate-200/60 dark:border-slate-800 py-8 text-center text-sm text-slate-500 dark:text-slate-400">
        PWA Demo • React + Tailwind • Mock/Open APIs ready
      </footer>
    </div>
  )
}

const ThemeToggle = ({ theme, setTheme }) => (
  <button aria-label="Toggle theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="ml-2 px-3 py-2 rounded-xl text-sm border border-slate-300 dark:border-slate-700">
    {theme === 'dark' ? 'Light' : 'Dark'}
  </button>
)

const BottomNav = () => (
  <nav className="fixed bottom-0 inset-x-0 z-40 md:hidden border-t border-slate-200/60 dark:border-slate-700 bg-white/90 dark:bg-slate-900/90 backdrop-blur">
    <div className="max-w-7xl mx-auto grid grid-cols-5 text-sm">
      {[
        ['Hotels','/hotels'],
        ['Transport','/transport'],
        ['Rentals','/rentals'],
        ['Food','/food'],
        ['Cost','/calculator'],
      ].map(([label, to]) => (
        <NavLink key={to} to={to} className={({isActive})=>`py-3 text-center ${isActive? 'font-semibold underline decoration-dotted' : ''}`}>{label}</NavLink>
      ))}
    </div>
  </nav>
)

const TopNavLink = ({ to, children }) => (
  <NavLink to={to} className={({ isActive }) => `px-3 py-2 rounded-xl text-sm font-medium hover:bg-slate-100 dark:hover:bg-slate-800 ${isActive ? 'bg-slate-900 text-white hover:bg-slate-900' : 'text-slate-700 dark:text-slate-200'}`}>{children}</NavLink>
)

const AuthContext = createContext(null);
const useAuth = () => useContext(AuthContext);
const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem('vp_user');
    return raw ? JSON.parse(raw) : null;
  });
  const login = (email, name) => { const u = { email, name }; localStorage.setItem('vp_user', JSON.stringify(u)); setUser(u); };
  const logout = () => { localStorage.removeItem('vp_user'); setUser(null); };
  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>
}
const AuthButtons = () => {
  const { user, logout } = useAuth();
  return user ? (
    <button onClick={logout} className="ml-2 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-sm">Logout</button>
  ) : (
    <Link to="/login" className="ml-2 px-3 py-2 rounded-xl bg-slate-900 text-white text-sm">Login</Link>
  );
}

const BookingContext = createContext(null);
const useBookings = () => useContext(BookingContext);
const BookingProvider = ({ children }) => {
  const [bookings, setBookings] = useState(() => {
    const raw = localStorage.getItem('vp_bookings');
    return raw ? JSON.parse(raw) : [];
  });
  useEffect(()=> localStorage.setItem('vp_bookings', JSON.stringify(bookings)), [bookings]);
  const addBooking = (item) => setBookings(b => [...b, { id: crypto.randomUUID(), ...item }]);
  const removeBooking = (id) => setBookings(b => b.filter(x=>x.id!==id));
  const clearAll = () => setBookings([]);
  const totals = useMemo(()=> ({ count: bookings.length, sum: bookings.reduce((a,x)=> a + (x.total || x.price || 0), 0)}), [bookings]);
  return <BookingContext.Provider value={{ bookings, addBooking, removeBooking, clearAll, totals }}>{children}</BookingContext.Provider>
}

const bannerAI = (title = 'Your Next Getaway') => `url('data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1600\" height=\"500\"><defs><linearGradient id=\"g\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#4f46e5\" offset=\"0\"/><stop stop-color=\"#06b6d4\" offset=\"1\"/></linearGradient></defs><rect width=\"100%\" height=\"100%\" fill=\"url(#g)\"/><g font-family=\"Inter, system-ui\" fill=\"white\" opacity=\"0.9\" font-size=\"64\"><text x=\"60\" y=\"240\" font-weight=\"700\">${title}</text><text x=\"60\" y=\"320\" font-size=\"28\" opacity=\"0.85\">AI-styled banner</text></g></svg>`)}')`;

const HOTELS = [
  { id: 'h1', name: 'Seabreeze Resort', city: 'Goa', price: 3499, rating: 4.5, img: bannerAI('Seabreeze Resort') },
  { id: 'h2', name: 'Himalayan Retreat', city: 'Manali', price: 2890, rating: 4.2, img: bannerAI('Himalayan Retreat') },
  { id: 'h3', name: 'Lakeview Inn', city: 'Udaipur', price: 3199, rating: 4.3, img: bannerAI('Lakeview Inn') },
  { id: 'h4', name: 'Cityscape Suites', city: 'Bengaluru', price: 4499, rating: 4.6, img: bannerAI('Cityscape Suites') },
];
const TRAINS = [
  { id: 't1', from: 'Bengaluru', to: 'Goa', time: '07:10', duration: '12h 30m', price: 980 },
  { id: 't2', from: 'Delhi', to: 'Jaipur', time: '09:40', duration: '4h 45m', price: 640 },
  { id: 't3', from: 'Mumbai', to: 'Pune', time: '06:30', duration: '3h 00m', price: 420 },
];
const BUSES = [
  { id: 'b1', from: 'Bengaluru', to: 'Coorg', time: '22:15', duration: '6h 10m', price: 750 },
  { id: 'b2', from: 'Hyderabad', to: 'Vijayawada', time: '21:00', duration: '5h 30m', price: 620 },
];
const RENTALS = [
  { id: 'r1', type: 'Car', name: 'Hatchback', seats: 4, price: 1600, img: bannerAI('Hatchback') },
  { id: 'r2', type: 'Car', name: 'SUV', seats: 7, price: 2600, img: bannerAI('SUV') },
  { id: 'r3', type: 'Bike', name: 'Scooter', seats: 2, price: 500, img: bannerAI('Scooter') },
];
const RESTAURANTS = [
  { id: 'f1', name: 'Spice Route', cuisine: 'Indian', city: 'Goa', price: 350, img: bannerAI('Spice Route') },
  { id: 'f2', name: 'Pasta Punto', cuisine: 'Italian', city: 'Mumbai', price: 480, img: bannerAI('Pasta Punto') },
  { id: 'f3', name: 'Sushi Garden', cuisine: 'Japanese', city: 'Bengaluru', price: 650, img: bannerAI('Sushi Garden') },
];

const Card = ({ children }) => (<div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">{children}</div>);
const ImgBanner = ({ bg }) => (<div className="h-40 w-full animated-banner" style={{ backgroundImage: bg, backgroundBlendMode: 'overlay' }} />);
const Price = ({ value }) => <span className="font-semibold">₹{value.toLocaleString()}</span>;

function Home(){
  const navigate = useNavigate();
  const [where, setWhere] = useState('');
  return (
    <>
      <Card>
        <div className="relative">
          <div className="h-48 sm:h-60 animated-banner" />
          <div className="absolute inset-0 bg-black/20" />
          <div className="absolute inset-0 flex items-center px-6">
            <div className="text-white max-w-2xl">
              <h1 className="text-3xl sm:text-4xl font-bold">Vacation Planner</h1>
              <p className="mt-2 opacity-90">Plan end-to-end trips, book options, and track costs — all in one place.</p>
              <div className="mt-4 bg-white/95 rounded-xl p-2 flex items-center gap-2 w-full">
                <input value={where} onChange={(e)=>setWhere(e.target.value)} placeholder="Where to? (e.g., Goa)" className="flex-1 px-3 py-3 rounded-lg outline-none" />
                <button onClick={()=> navigate('/hotels?city='+encodeURIComponent(where||'Goa'))} className="px-4 py-3 rounded-lg bg-slate-900 text-white">Search</button>
              </div>
              <div className="mt-3 text-sm opacity-95">Quick links: {['Hotels','Transport','Rentals','Food','Cost'].map((x)=> (
                <Link key={x} to={`/${x.toLowerCase()}`} className="underline decoration-dotted mr-3">{x}</Link>
              ))}</div>
            </div>
          </div>
        </div>
      </Card>
      <section className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {HOTELS.slice(0,4).map(h => (
          <motion.div key={h.id} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{duration:.3}}>
            <Card>
              <ImgBanner bg={h.img} />
              <div className="p-4">
                <div className="font-semibold">{h.name}</div>
                <div className="text-sm text-slate-600 dark:text-slate-300">{h.city}</div>
                <div className="mt-2"><Price value={h.price}/> / night</div>
                <Link to="/hotels" className="mt-3 inline-block px-3 py-2 rounded-lg bg-slate-900 text-white text-sm">Explore Hotels</Link>
              </div>
            </Card>
          </motion.div>
        ))}
      </section>
    </>
  )
}

function Hotels(){
  const { addBooking } = useBookings();
  const [city, setCity] = useState('');
  const list = useMemo(()=> HOTELS.filter(h => !city || h.city.toLowerCase().includes(city.toLowerCase())), [city]);
  const [nights, setNights] = useState(1);
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Hotels</h2>
      <div className="flex flex-wrap gap-3 mb-6 items-end">
        <div>
          <label className="text-sm">City</label>
          <input value={city} onChange={(e)=>setCity(e.target.value)} placeholder="e.g., Goa" className="block px-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"/>
        </div>
        <div>
          <label className="text-sm">Nights</label>
          <input type="number" min={1} value={nights} onChange={(e)=>setNights(parseInt(e.target.value||'1'))} className="block px-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 w-28 bg-white dark:bg-slate-900"/>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(h => (
          <Card key={h.id}>
            <ImgBanner bg={h.img} />
            <div className="p-4">
              <div className="font-semibold">{h.name}</div>
              <div className="text-sm text-slate-600 dark:text-slate-300">{h.city} • ⭐ {h.rating}</div>
              <div className="mt-2"><Price value={h.price}/> / night</div>
              <button className="mt-3 px-3 py-3 rounded-lg bg-slate-900 text-white text-sm w-full" onClick={()=> addBooking({ type:'hotel', ref:h.id, name:h.name, nights, price:h.price * nights, total: h.price * nights })}>Book {nights} night{nights>1?'s':''}</button>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}

function Transport(){
  const [tab, setTab] = useState('train');
  const { addBooking } = useBookings();
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const pool = tab === 'train' ? TRAINS : BUSES;
  const list = pool.filter(x => (!from || x.from.toLowerCase().includes(from.toLowerCase())) && (!to || x.to.toLowerCase().includes(to.toLowerCase())));
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Transport</h2>
      <div className="flex items-center gap-2 mb-4">
        {['train','bus'].map(k => (
          <button key={k} onClick={()=>setTab(k)} className={`px-4 py-2 rounded-xl border ${tab===k? 'bg-slate-900 text-white' : 'bg-white dark:bg-slate-900 dark:border-slate-700'}`}>{k.toUpperCase()}</button>
        ))}
      </div>
      <div className="flex flex-wrap gap-3 mb-6 items-end">
        <div>
          <label className="text-sm">From</label>
          <input value={from} onChange={(e)=>setFrom(e.target.value)} className="block px-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"/>
        </div>
        <div>
          <label className="text-sm">To</label>
          <input value={to} onChange={(e)=>setTo(e.target.value)} className="block px-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"/>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(x => (
          <Card key={x.id}>
            <ImgBanner bg={bannerAI(`${x.from} → ${x.to}`)} />
            <div className="p-4">
              <div className="font-semibold">{x.from} → {x.to}</div>
              <div className="text-sm text-slate-600 dark:text-slate-300">{x.time} • {x.duration}</div>
              <div className="mt-2"><Price value={x.price}/></div>
              <button className="mt-3 px-3 py-3 rounded-lg bg-slate-900 text-white text-sm w-full" onClick={()=> addBooking({ type: tab, ref:x.id, name:`${x.from} → ${x.to}`, price:x.price, total:x.price })}>Book</button>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}

function Rentals(){
  const [kind, setKind] = useState('All');
  const { addBooking } = useBookings();
  const list = RENTALS.filter(r => kind === 'All' || r.type === kind);
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Vehicle Rentals</h2>
      <div className="flex items-center gap-2 mb-4">
        {['All','Car','Bike'].map(k => (
          <button key={k} onClick={()=>setKind(k)} className={`px-4 py-2 rounded-xl border ${kind===k? 'bg-slate-900 text-white' : 'bg-white dark:bg-slate-900 dark:border-slate-700'}`}>{k}</button>
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(r => (
          <Card key={r.id}>
            <ImgBanner bg={r.img} />
            <div className="p-4">
              <div className="font-semibold">{r.name} • {r.type}</div>
              <div className="text-sm text-slate-600 dark:text-slate-300">Seats: {r.seats}</div>
              <div className="mt-2"><Price value={r.price}/> / day</div>
              <button className="mt-3 px-3 py-3 rounded-lg bg-slate-900 text-white text-sm w-full" onClick={()=> addBooking({ type:'rental', ref:r.id, name:`${r.type} – ${r.name}`, price:r.price, total:r.price })}>Reserve</button>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}

function Food(){
  const [city, setCity] = useState('');
  const { addBooking } = useBookings();
  const list = RESTAURANTS.filter(r => !city || r.city.toLowerCase().includes(city.toLowerCase()));
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Food Delivery</h2>
      <div className="flex flex-wrap gap-3 mb-6 items-end">
        <div>
          <label className="text-sm">City</label>
          <input value={city} onChange={(e)=>setCity(e.target.value)} placeholder="e.g., Goa" className="block px-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"/>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(f => (
          <Card key={f.id}>
            <ImgBanner bg={f.img} />
            <div className="p-4">
              <div className="font-semibold">{f.name}</div>
              <div className="text-sm text-slate-600 dark:text-slate-300">{f.cuisine} • {f.city}</div>
              <div className="mt-2">Avg order <Price value={f.price}/></div>
              <button className="mt-3 px-3 py-3 rounded-lg bg-slate-900 text-white text-sm w-full" onClick={()=> addBooking({ type:'food', ref:f.id, name:`${f.name} (${f.city})`, price:f.price, total:f.price })}>Order</button>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}

function Calculator(){
  const { bookings, totals, clearAll } = useBookings();
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Cost Calculator</h2>
      <Card>
        <div className="p-4">
          <div className="flex items-center justify-between">
            <div className="text-lg font-semibold">Total Items: {totals.count}</div>
            <div className="text-lg">Grand Total: <Price value={totals.sum} /></div>
          </div>
          <div className="mt-4 grid gap-3">
            {bookings.map(item => (
              <div key={item.id} className="flex items-center justify-between rounded-xl border border-slate-200 dark:border-slate-700 p-3">
                <div>
                  <div className="font-medium">{item.type.toUpperCase()} • {item.name}</div>
                  {item.nights ? <div className="text-sm text-slate-600 dark:text-slate-300">{item.nights} night(s)</div> : null}
                </div>
                <div className="font-semibold">₹{(item.total || item.price).toLocaleString()}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-2">
            <Link to="/bookings" className="px-4 py-2 rounded-lg bg-slate-900 text-white">Go to My Bookings</Link>
            <button onClick={clearAll} className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700">Clear All</button>
          </div>
        </div>
      </Card>
    </>
  )
}

function Bookings(){
  const { bookings, removeBooking, totals } = useBookings();
  const { user } = useAuth();
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">My Bookings</h2>
      {!user && (<div className="mb-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-sm">You are not logged in. Bookings are saved locally for demo.</div>)}
      <Card>
        <div className="p-4">
          <div className="text-sm text-slate-600 dark:text-slate-300 mb-2">Total: <Price value={totals.sum} /></div>
          <div className="grid gap-3">
            {bookings.length === 0 && <div className="text-slate-500 dark:text-slate-400">No bookings yet.</div>}
            {bookings.map(item => (
              <div key={item.id} className="flex items-center justify-between rounded-xl border border-slate-200 dark:border-slate-700 p-3">
                <div>
                  <div className="font-medium">{item.type.toUpperCase()} • {item.name}</div>
                  {item.nights ? <div className="text-sm text-slate-600 dark:text-slate-300">{item.nights} night(s)</div> : null}
                </div>
                <div className="flex items-center gap-3">
                  <div className="font-semibold">₹{(item.total || item.price).toLocaleString()}</div>
                  <button onClick={()=>removeBooking(item.id)} className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-sm">Cancel</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </>
  )
}

function Login(){
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  return (
    <Card>
      <div className="p-6 max-w-md">
        <h2 className="text-2xl font-bold">Login</h2>
        <p className="text-sm text-slate-600 dark:text-slate-300">Demo login (no password). Later you can plug Firebase Auth.</p>
        <div className="mt-4 grid gap-3">
          <div>
            <label className="text-sm">Name</label>
            <input value={name} onChange={(e)=>setName(e.target.value)} className="block w-full px-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"/>
          </div>
          <div>
            <label className="text-sm">Email</label>
            <input value={email} onChange={(e)=>setEmail(e.target.value)} className="block w-full px-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"/>
          </div>
          <button onClick={()=>{login(email||'guest@example.com', name||'Guest'); navigate('/bookings');}} className="px-4 py-3 rounded-lg bg-slate-900 text-white">Login</button>
          <Link to="/signup" className="text-sm underline">No account? Sign up</Link>
        </div>
      </div>
    </Card>
  )
}

function Signup(){
  const navigate = useNavigate();
  return (
    <Card>
      <div className="p-6 max-w-md">
        <h2 className="text-2xl font-bold">Create Account</h2>
        <p className="text-sm text-slate-600 dark:text-slate-300">For demo, the login form is enough. In production, wire this to Firebase Auth.</p>
        <div className="mt-4 grid gap-3">
          <Link to="/login" className="px-4 py-3 rounded-lg bg-slate-900 text-white text-center">Continue to Login</Link>
          <button onClick={()=>navigate(-1)} className="px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-700">Back</button>
        </div>
      </div>
    </Card>
  )
}

export default function App(){
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <BookingProvider>
            <Shell>
              <AnimatePresence mode="wait">
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/hotels" element={<Hotels />} />
                  <Route path="/transport" element={<Transport />} />
                  <Route path="/rentals" element={<Rentals />} />
                  <Route path="/food" element={<Food />} />
                  <Route path="/calculator" element={<Calculator />} />
                  <Route path="/bookings" element={<Bookings />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/signup" element={<Signup />} />
                </Routes>
              </AnimatePresence>
            </Shell>
          </BookingProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  )
}
